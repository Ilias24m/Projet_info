#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h> 
#include "snakeAPI.h"
#include "Snakestruct.h"

int main() {
	printf("Test\n");
	//Initialise la connexion avec le serveur
	connectToServer("localhost", 1234, "PythonSlayer24");
	
	//Attendre que le serveur démarre le jeu
	char gameType[40];
	char gameName[10] = "Partie"; 
	int sizeX = 2;
	int sizeY = 2; 
	int nbWalls = 2;
	waitForSnakeGame(strcpy(gameType,"TRAINING SUPER_PLAYER difficulty=2"), strcpy(gameName,"Partie"), &sizeX, &sizeY,&nbWalls);
	printf("%d  %d\n", sizeX, sizeY);
	// Récupérer l'emplacement des murs de l'arène et le joueur commence
    int walls[4 * nbWalls];
    int player1 = getSnakeArena(walls);
    int player2 = (player1 + 1) % 2;
    // Boucle de jeu
    Snake* MySnake = malloc(sizeof(Snake));
    Snake* opponentSnake = malloc(sizeof(Snake));
    initializeSnake(MySnake, player1, sizeX, sizeY);
    initializeSnake(opponentSnake, player2, sizeX, sizeY);
    while (1) {
    	//Démarrage du jeu
    	printf("Le jeu commence....\n");
    	//Affichage de l'état actuel de l'arène
    	printArena();
        //printf("position x = %d\n", MySnake->segments->x);
        //printf("position y = %d\n", MySnake->segments->y);
        
        Position* snakePosition = MySnake->segments;
        getSnakePosition(MySnake, snakePosition);

        t_move move;



        /////////////OLD FUNCTION////////////////////////
        /*bool wallInFront;
        int direction = MySnake->direction;

        
        if (MySnake->move_count == 0){
            direction = ((MySnake->direction + 1) % 4);
        }
        
        
        for (int i=0; i<=3; i++){
            MySnake->possible_directions[i] = false;
        }

        wallInFront = check_walls_and_snakes( MySnake,  opponentSnake, direction, walls, nbWalls, sizeX, sizeY, 4);
        move = MySnake->direction;
        Snake snake = *MySnake;
        snake.direction = move;
        update_snake(&snake);

        if (!wallInFront) {
            wallInFront = check_walls_and_snakes( &snake,  opponentSnake, snake.direction, walls, nbWalls, sizeX, sizeY, 4);
            //printf("wallInFront = %d\n", wallInFront);
            if (!wallInFront) {
                move = MySnake->direction;
                //break;
            }
            else {
                direction = ((direction + 1) % 4);
                wallInFront = check_walls_and_snakes( MySnake,  opponentSnake, direction, walls, nbWalls, sizeX, sizeY, MySnake->direction);
                move = MySnake->direction;
                if (wallInFront){
                    printf("Future collision detected!\n");
                }
            }
        }
        else {
            printf("Collision detected!\n");
            //break;
        }*/

    

    /////////////////NEW FUNCTION////////////////////////
    int futureSteps = 50; // Nombre de coups à anticiper

    // Appel de la fonction pour faire un mouvement
    make_move(MySnake, opponentSnake, walls, nbWalls, sizeX, sizeY, futureSteps);
    move = MySnake->direction;



      

        /*decide_move(MySnake, opponentSnake, walls, nbWalls, sizeX, sizeY, 2);
        move = MySnake->direction;*/
        
        
        
        //printf("MySnake direction = %d\n", MySnake->direction);
        printf("direction = %d\n", move);

        if (player1 == 0){
            // Envoyer le mouvement au serveur
            t_return_code ret = sendMove(move);
            
            if (ret == LOSING_MOVE) {
                printf("Vous avez perdu!\n");
                break;
            } else if (ret == WINNING_MOVE) {
                printf("Félicitations! Vous avez gagné!\n");
                break;
            }

            // Récupérer le mouvement de l'adversaire
            t_move opponentMove;
            ret = getMove(&opponentMove);
            opponentSnake->direction = opponentMove;
            if (ret == LOSING_MOVE) {
                printf("L'adversaire a perdu!\n");
                break;
            } else if (ret == WINNING_MOVE) {
                printf("L'adversaire a gagné!\n");
                break;
            }
        }
        else{
        // Récupérer le mouvement de l'adversaire
            t_move opponentMove;
            t_return_code ret = getMove(&opponentMove);
            opponentSnake->direction = opponentMove;
            if (ret == LOSING_MOVE) {
                printf("L'adversaire a perdu!\n");
                break;
            } else if (ret == WINNING_MOVE) {
                printf("L'adversaire a gagné!\n");
                break;
            }

            // Envoyer le mouvement au serveur
            ret = sendMove(move);
            if (ret == LOSING_MOVE) {
                printf("Vous avez perdu!\n");
                break;
            } else if (ret == WINNING_MOVE) {
                printf("Félicitations! Vous avez gagné!\n");
                break;
            }
        }
        update_snake(MySnake);
        update_snake(opponentSnake);
        
    }
    //printf("taille du Snake %d\n", MySnake->length);
	free(MySnake);
    free(opponentSnake);
	//Ferme la connection avec le serveur 
	closeConnection();
	return 0;
}
