// File: main.c
#include "snakeAPI.h"
#include <stdio.h>
#include <stdlib.h>

// Constants
#define MAX_WALLS 25
#define MAX_SNAKE_LENGTH 100

typedef struct {
    int x;
    int y;
} Position;

typedef struct {
    int width;
    int height;
    Position walls[MAX_WALLS * 4];
    int nbWalls;
} Arena;

typedef struct {
    Position segments[MAX_SNAKE_LENGTH];
    int length;
    int direction;
} Snake;

void initialize_arena(Arena* arena, int sizeX, int sizeY, int* walls, int nbWalls) {
    arena->width = sizeX;
    arena->height = sizeY;
    arena->nbWalls = nbWalls;
    for (int i = 0; i < 4 * nbWalls; i++) {
        arena->walls[i].x = walls[2 * i];
        arena->walls[i].y = walls[2 * i + 1];
    }
}

void initialize_snake(Snake* snake, Position start_pos) {
    snake->length = 1;
    snake->segments[0] = start_pos;
    snake->direction = EAST;
}

void update_snake(Snake* snake) {
    Position new_head = snake->segments[0];
    switch (snake->direction) {
        case NORTH: new_head.y -= 1; break;
        case EAST: new_head.x += 1; break;
        case SOUTH: new_head.y += 1; break;
        case WEST: new_head.x -= 1; break;
    }

    for (int i = snake->length; i > 0; i--) {
        snake->segments[i] = snake->segments[i - 1];
    }
    snake->segments[0] = new_head;
    snake->length += 1;
}

int check_collision(Arena* arena, Snake* snake) {
    Position head = snake->segments[0];
    for (int i = 0; i < arena->nbWalls * 4; i++) {
        if (head.x == arena->walls[i].x && head.y == arena->walls[i].y) {
            return 1;
        }
    }
    for (int i = 1; i < snake->length; i++) {
        if (head.x == snake->segments[i].x && head.y == snake->segments[i].y) {
            return 1;
        }
    }
    return 0;
}

void initialize_game(char* server_name, int port, char* player_name, int* sizeX, int* sizeY, int* nbWalls, int* walls) {
    connectToServer(server_name, port, player_name);
    char game_type[] = "TRAINING RANDOM_PLAYER difficulty=2 timeout=100";
    char game_name[50];
    waitForSnakeGame(game_type, game_name, sizeX, sizeY, nbWalls);
    getSnakeArena(walls);
}

void game_loop(Arena* arena, Snake* snake) {
    int game_over = 0;
    t_move move;
    t_return_code move_result;

    while (!game_over) {
        printf("Enter move direction (0: NORTH, 1: EAST, 2: SOUTH, 3: WEST): ");
        int direction;
        scanf("%d", &direction);

        snake->direction = direction;
        update_snake(snake);

        if (check_collision(arena, snake)) {
            printf("Collision detected!\n");
            game_over = 1;
        } else {
            move = (t_move)direction;
            move_result = sendMove(move);

            if (move_result == WINNING_MOVE || move_result == LOSING_MOVE) {
                game_over = 1;
            } else {
                t_move opponent_move;
                getMove(&opponent_move);
                printArena();
            }
        }
    }
}

int main() {
    int sizeX, sizeY, nbWalls;
    int walls[100];
    Arena arena;
    Snake snake;
    Position start_pos = {2, 10}; // Example start position

    initialize_game("pc5039", 1234, "Player1", &sizeX, &sizeY, &nbWalls, walls);
    initialize_arena(&arena, sizeX, sizeY, walls, nbWalls);
    initialize_snake(&snake, start_pos);
    game_loop(&arena, &snake);
    closeConnection();

    return 0;
}




// File: main.c
#include "snakeAPI.h"
#include <stdio.h>
#include <stdlib.h>

// Constants
#define MAX_WALLS 25
#define MAX_SNAKE_LENGTH 100

typedef struct {
    int x;
    int y;
} Position;

typedef struct {
    int width;
    int height;
    Position walls[MAX_WALLS * 4];
    int nbWalls;
} Arena;

typedef struct {
    Position segments[MAX_SNAKE_LENGTH];
    int length;
    int direction;
} Snake;

// Direction constants
#define NORTH 0
#define EAST 1
#define SOUTH 2
#define WEST 3

void initialize_arena(Arena* arena, int sizeX, int sizeY, int* walls, int nbWalls) {
    arena->width = sizeX;
    arena->height = sizeY;
    arena->nbWalls = nbWalls;
    for (int i = 0; i < 4 * nbWalls; i++) {
        arena->walls[i].x = walls[2 * i];
        arena->walls[i].y = walls[2 * i + 1];
    }
}

void initialize_snake(Snake* snake, Position start_pos) {
    snake->length = 1;
    snake->segments[0] = start_pos;
    snake->direction = EAST; // Example direction
}

void update_snake(Snake* snake) {
    // Implementation of snake movement...
}

int check_collision(Arena* arena, Snake* snake) {
    // Implementation of collision detection...
}

void initialize_game(char* server_name, int port, char* player_name, int* sizeX, int* sizeY, int* nbWalls, int* walls) {
    // Implementation of initializing game...
}

void game_loop(Arena* arena, Snake* snake) {
    // Implementation of game loop...
}

int main() {
    // Implementation of main function...
    return 0;
}









snake_x, snake_y = getSnakePosition()
snake_direction = getSnakeDirection()

for i in range(0, len(walls), 4):
    wall_start_x, wall_start_y, wall_end_x, wall_end_y = walls[i], walls[i+1], walls[i+2], walls[i+3]
    
    if snake_direction is north and wall_start_y < snake_y and wall_end_y > snake_y and wall_start_x == snake_x:
        return True  # There is a wall in front
    elif snake_direction is east and wall_start_x > snake_x and wall_end_x < snake_x and wall_start_y == snake_y:
        return True  # There is a wall in front
    # Repeat for other directions

return False  # There is no wall in front










#include <stdbool.h>

typedef struct {
    int x;
    int y;
} Segment;

typedef struct {
    Segment* segments; // Assuming the head of the snake is the first segment
} Snake;

bool isWallInFront(Snake* snake, int* walls, int nbW, int snake_direction) {
    for (int i = 0; i < nbW * 4; i += 4) {
        int wall_start_x = walls[i];
        int wall_start_y = walls[i+1];
        int wall_end_x = walls[i+2];
        int wall_end_y = walls[i+3];

        if (snake_direction == NORTH) {
            if (snake->segments->y > wall_start_y && wall_start_x == snake->segments->x && wall_end_x == snake->segments->x && 
                ((wall_start_y <= snake->segments->y && wall_end_y >= snake->segments->y) || 
                 (wall_start_y >= snake->segments->y && wall_end_y <= snake->segments->y))) {
                return true;  // There is a wall in front (North)
            }
        } else if (snake_direction == EAST) {
            if (snake->segments->x < wall_start_x && wall_start_y == snake->segments->y && wall_end_y == snake->segments->y && 
                ((wall_start_x <= snake->segments->x && wall_end_x >= snake->segments->x) || 
                 (wall_start_x >= snake->segments->x && wall_end_x <= snake->segments->x))) {
                return true;  // There is a wall in front (East)
            }
        } else if (snake_direction == SOUTH) {
            if (snake->segments->y < wall_start_y && wall_start_x == snake->segments->x && wall_end_x == snake->segments->x && 
                ((wall_start_y <= snake->segments->y && wall_end_y >= snake->segments->y) || 
                 (wall_start_y >= snake->segments->y && wall_end_y <= snake->segments->y))) {
                return true;  // There is a wall in front (South)
            }
        } else if (snake_direction == WEST) {
            if (snake->segments->x > wall_start_x && wall_start_y == snake->segments->y && wall_end_y == snake->segments->y && 
                ((wall_start_x <= snake->segments->x && wall_end_x >= snake->segments->x) || 
                 (wall_start_x >= snake->segments->x && wall_end_x <= snake->segments->x))) {
                return true;  // There is a wall in front (West)
            }
        }
    }

    return false;  // There is no wall in front
}





typedef struct{
    int cells[100][100];
    int nbWalls;
    int sizeX;
    int sizeY;

}arena;

void getArena (arena* arena, int* walls, int nbWalls, int sizeX, int sizeY){
    arena->sizeX = sizeX;
    arena->sizeY = sizeY;
    arena->nbWalls = nbWalls;
    for (int i = 0; i < nbWalls * 4; i++) {
        arena->cells[walls[4*i]][walls[4*i+1]];
        arena->cells[walls[4*i+2]][walls[4*i+3]];
    }
}

bool isWallInFront(Snake* snake, int* walls, int nbW, int snake_direction, int sizeX, int sizeY) {
    for (int i = 0; i < nbW * 4; i += 4) {
        int wall_start_x = walls[i];
        int wall_start_y = walls[i+1];
        int wall_end_x = walls[i+2];
        int wall_end_y = walls[i+3];

        if (snake_direction == NORTH) {
            if (((snake->segments->y > wall_start_y && wall_start_x == snake->segments->x && wall_end_x == snake->segments->x) && 
                ((wall_start_y <= snake->segments->y && wall_end_y >= snake->segments->y) || 
                 (wall_start_y >= snake->segments->y && wall_end_y <= snake->segments->y)))||snake->segments->y == 0) {
                return true;  // There is a wall in front (North)
                printf("mur detecter\n");
            }
        } else if (snake_direction == EAST) {
            if (((snake->segments->x < wall_start_x && wall_start_y == snake->segments->y && wall_end_y == snake->segments->y) && 
                ((wall_start_x <= snake->segments->x && wall_end_x >= snake->segments->x) || 
                 (wall_start_x >= snake->segments->x && wall_end_x <= snake->segments->x)))||snake->segments->x == sizeX - 1) {
                return true;  // There is a wall in front (East)
            }
        } else if (snake_direction == SOUTH) {
            if (((snake->segments->y < wall_start_y && wall_start_x == snake->segments->x && wall_end_x == snake->segments->x) && 
                ((wall_start_y <= snake->segments->y && wall_end_y >= snake->segments->y) || 
                 (wall_start_y >= snake->segments->y && wall_end_y <= snake->segments->y)))||snake->segments->y == sizeY - 1) {
                return true;  // There is a wall in front (South)
            }
        } else if (snake_direction == WEST) {
            if (((snake->segments->x > wall_start_x && wall_start_y == snake->segments->y && wall_end_y == snake->segments->y) && 
                ((wall_start_x <= snake->segments->x && wall_end_x >= snake->segments->x) || 
                 (wall_start_x >= snake->segments->x && wall_end_x <= snake->segments->x)))||snake->segments->x == 0) {
                return true;  // There is a wall in front (West)
            }
        }
    }

    return false;  // There is no wall in front
}



int isWall(Arena *arena, int x, int y, Position ma_position) {
    for (int i = 0; i < arena->numWalls; i++) {

        // Extraire les coordonnées qui entoure chaque murs
        int x1 = arena->walls[i].start.x;
        int y1 = arena->walls[i].start.y;
        int x2 = arena->walls[i].end.x;
        int y2 = arena->walls[i].end.y;

        // Extraire la position de la potentielle destination
        Position destination;
        destination.x = x;
        destination.y = y;

        // Vérifier si de la position (x, y), on risque de rentrer dans le mur qui sépare (x,y) de notre destination
        if (((ma_position.x == x1 && ma_position.y == y1) || (ma_position.x == x2 && ma_position.y == y2))){
            if (((destination.x == x1 && destination.y == y1) || (destination.x == x2 && destination.y == y2))){
                return 1;
            }
        }
    }
    return 0;
}

void getSnakePosition(Snake* snake, Position* position) {
    position->x = snake->segments->x;
    position->y = snake->segments->y;
}









typedef struct {
    int x;
    int y;
} Position;

typedef struct {
    int id;
    Position segments[MAX_SNAKE_LENGTH];
    float length;
    int direction;
} Snake;

void initializeSnake(Snake* snake, int id, int sizeX, int sizeY) {
    snake->length = 1;

    if (id == 0) {
        snake->segments[0].x = 2;
        snake->segments[0].y = sizeY / 2;
        snake->direction = EAST;
    } else if (id == 1) {
        snake->segments[0].x = sizeX - 3;
        snake->segments[0].y = sizeY / 2;
        snake->direction = WEST;
    }
}

void update_snake(Snake* snake) {
    Position new_head = snake->segments[0];
    if (snake->direction == NORTH) {
        new_head.y -= 1;
    } else if (snake->direction == EAST) {
        new_head.x += 1;
    } else if (snake->direction == SOUTH) {
        new_head.y += 1;
    } else if (snake->direction == WEST) {
        new_head.x -= 1;
    }

    for (int i = (int)snake->length; i > 0; i--) {
        snake->segments[i] = snake->segments[i - 1];
        printf("position x = %d, position y = %d\n", snake->segments[i].x, snake->segments[i].y);
    }
    snake->segments[0] = new_head;

    // Augmentez la longueur du serpent si nécessaire
    if (snake->length < MAX_SNAKE_LENGTH) {
        snake->length += 0.1;
    }

    printf("Next move position x = %d, position y = %d\n", snake->segments[0].x, snake->segments[0].y);
}

bool isWallInFront(Snake* snake, int* walls, int nbW, int snake_direction, int sizeX, int sizeY) {
    for (int i = 0; i < nbW * 4; i += 4) {
        int x1 = walls[i];
        int y1 = walls[i+1];
        int x2 = walls[i+2];
        int y2 = walls[i+3];

        if (snake_direction == NORTH) {
            if ((((snake->segments[0].y == y2 && snake->segments[0].x == x2)&&((snake->segments[0].y-1 == y1) && snake->segments[0].x == x1))||((snake->segments[0].y == y1 && snake->segments[0].x == x1)&&((snake->segments[0].y-1 == y2) && snake->segments[0].x == x2)))||snake->segments[0].y == 0) {
                printf("mur detecter NORTH\n");
                return true;  // There is a wall in front (North)
            }
        } else if (snake_direction == EAST) {
            if ((((snake->segments[0].x == x1 && snake->segments[0].y == y1)&&((snake->segments[0].x+1 == x2) && snake->segments[0].y == y2))||((snake->segments[0].x == x2 && snake->segments[0].y == y2)&&((snake->segments[0].x+1 == x1) && snake->segments[0].y == y1)))||snake->segments[0].x == sizeX - 1) {
                printf("mur detecter EAST\n");
                return true;  // There is a wall in front (East)
                
            }
        } else if (snake_direction == SOUTH) {
            if ((((snake->segments[0].y == y1 && snake->segments[0].x == x1)&&((snake->segments[0].y+1 == y2) && snake->segments[0].x == x2))||((snake->segments[0].y == y2 && snake->segments[0].x == x2)&&((snake->segments[0].y+1 == y1) && snake->segments[0].x == x1)))||snake->segments[0].y == sizeY - 1) {
                printf("mur detecter SOUTH\n");
                return true;  // There is a wall in front (South)
                
            }
        } else if (snake_direction == WEST) {
            if ((((snake->segments[0].x == x2 && snake->segments[0].y == y2)&&((snake->segments[0].x-1 == x1) && snake->segments[0].y == y1))||((snake->segments[0].x == x1 && snake->segments[0].y == y1)&&((snake->segments[0].x-1 == x2) && snake->segments[0].y == y2)))||snake->segments[0].x == 0) {
                printf("mur detecter WEST\n");
                return true;  // There is a wall in front (West)
                
            }
        }
    }

    return false;  // There is no wall in front
}

bool isSnakeSegmentInFront(Snake* snake) {
    if (snake->direction == NORTH){
        for (int i = 1; i < (int)snake->length; i++) {
            if ((snake->segments[0].x == snake->segments[i].x) && ((snake->segments[0].y - 1) == snake->segments[i].y)) {
                printf("snake detecter position %d %d\n", snake->segments[i].x, snake->segments[i].y);
                return true;
            }
        } 
    } else if (snake->direction == EAST){
        for (int i = 1; i < (int)snake->length; i++) {
            if (((snake->segments[0].x + 1) == snake->segments[i].x) && (snake->segments[0].y == snake->segments[i].y)) {
                printf("snake detecter position %d %d\n", snake->segments[i].x, snake->segments[i].y);
                return true;
            }
        }
    } else if (snake->direction == SOUTH){
        for (int i = 1; i < (int)snake->length; i++) {
            if ((snake->segments[0].x == snake->segments[i].x) && ((snake->segments[0].y + 1) == snake->segments[i].y)) {
                printf("snake detecter position %d %d\n", snake->segments[i].x, snake->segments[i].y);
                return true;
            }
        }
    } else if (snake->direction == WEST){
        for (int i = 1; i < (int)snake->length; i++) {
            if (((snake->segments[0].x - 1) == snake->segments[i].x) && (snake->segments[0].y == snake->segments[i].y)) {
                printf("snake detecter position %d %d\n", snake->segments[i].x, snake->segments[i].y);
                return true;
            }
        }
    }
    printf("snake non detecter\n");
    return false;
}
void getSnakePosition(Snake* snake, Position* position) {
    position->x = snake->segments->x;
    position->y = snake->segments->y;
}





bool checkNextMove(Snake* snake, int direction, int* walls, int nbWalls, int sizeX, int sizeY) {
    //int direction = snake->direction;
    for (int i = 0; i <= 3; i ++) {
        if (isWallInFront(snake, walls, nbWalls, direction, sizeX, sizeY) == false){
            if((isSnakeSegmentInFront(snake, direction) == false) && (isSnakeInFront(snake, snake, direction) == false) ){
                return true;
            }
        }
        if ((isWallInFront(snake, walls, nbWalls, i, sizeX, sizeY) == false) && (i != ((snake->direction + 2) % 4))){
            if ((isSnakeSegmentInFront(snake, i) == false) && (isSnakeInFront(snake, snake, i) == false)){
                return true;
            }
        }
    }
    return false;
}





























#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h> 
#include "snakeAPI.h"
#include "Snakestruct.h"

int main() {
	printf("Test\n");
	//Initialise la connexion avec le serveur
	connectToServer("localhost", 1234, "PythonSlayer");
	
	//Attendre que le serveur démarre le jeu
	char gameType[40];
	char gameName[10] = "Partie"; 
	int sizeX = 2;
	int sizeY = 2; 
	int nbWalls = 2;
	waitForSnakeGame(strcpy(gameType,"TRAINING SUPER_PLAYER difficulty=2"), strcpy(gameName,"Partie"), &sizeX, &sizeY,&nbWalls);
	printf("%d  %d\n", sizeX, sizeY);
	// Récupérer l'emplacement des murs de l'arène et le joueur commence
    int walls[4 * nbWalls];
    int player1 = getSnakeArena(walls);
    int player2 = (player1 + 1) % 2;
    // Boucle de jeu
    Snake* MySnake = malloc(sizeof(Snake));
    Snake* opponentSnake = malloc(sizeof(Snake));
    initializeSnake(MySnake, player1, sizeX, sizeY);
    initializeSnake(opponentSnake, player2, sizeX, sizeY);
    while (1) {
    	//Démarrage du jeu
    	printf("Le jeu commence....\n");
    	//Affichage de l'état actuel de l'arène
    	printArena();
        //printf("position x = %d\n", MySnake->segments->x);
        //printf("position y = %d\n", MySnake->segments->y);
        
        Position* snakePosition = MySnake->segments;
        getSnakePosition(MySnake, snakePosition);

        t_move move;
        bool wallInFront;
        int direction = MySnake->direction;
        /*for(int i = 0; i < MySnake->length; i++) {
            printf("position x = %d, position y = %d\n", opponentSnake->segments[i].x, opponentSnake->segments[i].y);
        }*/
        
        if (MySnake->move_count == 0){
            direction = ((MySnake->direction + 1) % 4);
        }
        
        /*for (int i = 0; i <= 3; i ++) {
            if (isWallInFront(MySnake, walls, nbWalls, direction, sizeX, sizeY) == false){
                if((isSnakeSegmentInFront(MySnake, direction) == false) && (isSnakeInFront(MySnake, opponentSnake, direction) == false) ){
                    move = direction;
                    wallInFront = false;
                    printf("mur non detecter\n");
                    break;
                }
            }
            if ((isWallInFront(MySnake, walls, nbWalls, i, sizeX, sizeY) == false) && (i != ((MySnake->direction + 2) % 4))){
                if ((isSnakeSegmentInFront(MySnake, i) == false) && (isSnakeInFront(MySnake, opponentSnake, i) == false)){
                    move = i;
                    wallInFront = false;
                    printf("mur non detecter\n");
                    break;
                }
            }
            else {
                wallInFront = true;
            } 
        }*/
        wallInFront = check_walls_and_snakes( MySnake,  opponentSnake, direction, walls, nbWalls, sizeX, sizeY);
        //move = MySnake->direction;
        Snake* snake = malloc(sizeof(Snake));
        snake = MySnake;
        //snake->direction = move;
        update_snake(snake);
        if (!wallInFront) {
            wallInFront = check_walls_and_snakes( snake,  opponentSnake, direction, walls, nbWalls, sizeX, sizeY);
            if (wallInFront) {
                wallInFront = check_walls_and_snakes( MySnake,  opponentSnake, direction, walls, nbWalls, sizeX, sizeY);
                
            }
        }
        else {
            printf("Collision detected!\n");
            //break;
        }   
        move = MySnake->direction;
        printf("direction = %d\n", move);

        if (player1 == 0){
            // Envoyer le mouvement au serveur
            t_return_code ret = sendMove(move);
            
            if (ret == LOSING_MOVE) {
                printf("Vous avez perdu!\n");
                break;
            } else if (ret == WINNING_MOVE) {
                printf("Félicitations! Vous avez gagné!\n");
                break;
            }

            // Récupérer le mouvement de l'adversaire
            t_move opponentMove;
            ret = getMove(&opponentMove);
            opponentSnake->direction = opponentMove;
            if (ret == LOSING_MOVE) {
                printf("L'adversaire a perdu!\n");
                break;
            } else if (ret == WINNING_MOVE) {
                printf("L'adversaire a gagné!\n");
                break;
            }
        }
        else{
        // Récupérer le mouvement de l'adversaire
            t_move opponentMove;
            t_return_code ret = getMove(&opponentMove);
            opponentSnake->direction = opponentMove;
            if (ret == LOSING_MOVE) {
                printf("L'adversaire a perdu!\n");
                break;
            } else if (ret == WINNING_MOVE) {
                printf("L'adversaire a gagné!\n");
                break;
            }

            // Envoyer le mouvement au serveur
            ret = sendMove(move);
            if (ret == LOSING_MOVE) {
                printf("Vous avez perdu!\n");
                break;
            } else if (ret == WINNING_MOVE) {
                printf("Félicitations! Vous avez gagné!\n");
                break;
            }
        }
        update_snake(MySnake);
        update_snake(opponentSnake);
        
    }
    //printf("taille du Snake %d\n", MySnake->length);
	free(MySnake);
	//Ferme la connection avec le serveur 
	closeConnection();
	return 0;
}
