        int N = 1;
        bool wallInFront[N];

        for(int dir = 0; dir < 4 ; dir++){    
            if(dir == ((MySnake->direction + 2) % 4)){
                continue;
            }
            Snake snake = *MySnake;
            snake.direction = dir;
            for(int i = 0; i<=N; i++){
                printf("direction = %d\n", dir);
                //printf(" AVANT snake.segments[0].x = %d  snake.segments[0].y = %d\n", snake.segments[0].x, snake.segments[0].y);
                wallInFront[i] = check_walls_and_snakes( &snake,  opponentSnake, snake.direction, walls, nbWalls, sizeX, sizeY, 4);
                printf("wallInFront[%d] = %d\n", i, wallInFront[i]);
                update_snake(&snake);
                //printf(" APRES snake.segments[0].x = %d  snake.segments[0].y = %d\n", snake.segments[0].x, snake.segments[0].y);
                if(wallInFront[i] == true){
                    break;
                }
                else{
                    move = dir;
                    
                }
            }
        }
        
        MySnake->direction = move;








// -----------------------Version avancée pour trouver un coup---------------------

t_move recherche_super_coup(Snake snake, Arena arène){

    // Force de coup initiale
    int coups_east = 0;
    int coups_west = 0;
    int coups_north = 0;
    int coups_south = 0;

    if((coup_possible(snake.coo_tete.x + 1,snake.coo_tete.y,arène)) && (recherche_simple_mur(snake.coo_tete.x,snake.coo_tete.y,snake.coo_tete.x+1,snake.coo_tete.y,arène) == 0)){
        coo* tab_xy = malloc(200 * sizeof(coo));
        coups_east = coup_autour_case(snake.coo_tete.x + 1, snake.coo_tete.y, arène, N_force, tab_xy,0); // N générique du tout début pour la force
        free (tab_xy);
        printf("Force de %d à l'est \n",coups_east);
    }

    if((coup_possible(snake.coo_tete.x - 1,snake.coo_tete.y,arène))&&(recherche_simple_mur(snake.coo_tete.x,snake.coo_tete.y,snake.coo_tete.x-1,snake.coo_tete.y,arène) == 0) ){
        coo* tab_xy = malloc(200 * sizeof(coo));
        coups_west = coup_autour_case(snake.coo_tete.x - 1, snake.coo_tete.y, arène, N_force,tab_xy,0 );
        free (tab_xy);
        printf("Force de %d à l'ouest \n",coups_west);
    }

    if((coup_possible(snake.coo_tete.x,snake.coo_tete.y - 1,arène))&&(recherche_simple_mur(snake.coo_tete.x,snake.coo_tete.y,snake.coo_tete.x,snake.coo_tete.y-1,arène) == 0)){
        coo* tab_xy = malloc(200 * sizeof(coo));
        coups_north = coup_autour_case(snake.coo_tete.x, snake.coo_tete.y - 1, arène, N_force,tab_xy,0);
        free (tab_xy);
        printf("Force de %d au nord \n",coups_north);
    }

    if((coup_possible(snake.coo_tete.x,snake.coo_tete.y + 1,arène))&&(recherche_simple_mur(snake.coo_tete.x,snake.coo_tete.y,snake.coo_tete.x,snake.coo_tete.y+1,arène) == 0)){
        coo* tab_xy = malloc(200 * sizeof(coo));
        coups_south = coup_autour_case(snake.coo_tete.x, snake.coo_tete.y + 1, arène, N_force,tab_xy,0 );
        free (tab_xy);
        printf("Force de %d au sud \n",coups_south);
    }

    int max_coups = max(coups_east, coups_west, coups_north, coups_south);

    if (max_coups == coups_east){
        //coups l'est est = max
        return EAST;
    }
    if (max_coups == coups_west){
        //coups l'ouest est = max
        return WEST;
    }
    if (max_coups == coups_north){
        //coups le nord est = max
        return NORTH;
    }
    if (max_coups == coups_south){
        //coups le sud est = max
        return SOUTH;
    }

    //recherche_ super_coup echouée, pas de coo autour possibles, envoi south !
    return SOUTH;
}

// -------------------Recherche la puissance du coup----------------------


int coup_autour_case(int x_case, int y_case, Arena arena, int N, coo* tab_xy, int i){ // Le N choisis à combien de coups je regarde à l'avance
    int x = x_case;
    int y = y_case;
    int coups = 0;

    for (int j = 0; j < i; j++) {
        if (tab_xy[j].x == x && tab_xy[j].y == y) {
            return coups;
        }
    }

    tab_xy[i].x = x;
    tab_xy[i].y = y;
    i++;

    if (N == 0) { // cran d'arret, oui j'abuse des parentheses
        return coups;
    }
    
    if(coup_possible(x + 1, y, arena) && recherche_simple_mur(x, y, x+1, y, arena) == 0){
        coups = coups + 1 + coup_autour_case(x+1, y, arena, N-1,tab_xy, i );
    }
    if(coup_possible(x - 1, y, arena) && recherche_simple_mur(x, y, x-1, y, arena) == 0){
        coups = coups + 1 + coup_autour_case(x-1, y, arena, N-1,tab_xy, i);
    }
    if(coup_possible(x, y - 1, arena) && recherche_simple_mur(x, y, x, y-1, arena) == 0){
        coups = coups + 1 + coup_autour_case(x, y-1, arena, N-1,tab_xy ,i);
    }
    if(coup_possible(x, y + 1, arena) && recherche_simple_mur(x, y, x, y+1, arena) == 0){
        coups = coups + 1 + coup_autour_case(x, y+1, arena, N-1, tab_xy, i );
    }

    // printf("Il y a %d coups possibles en %d;%d \n", coups, x, y);
    return coups;
}